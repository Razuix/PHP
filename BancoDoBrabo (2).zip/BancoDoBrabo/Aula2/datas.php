<?php 
    
    echo"<b> Hoje é dia </b>";
    echo date ("d/M/y");
    echo "<b> e são </b>";
    echo date ("H;i:s");
    echo "<hr>";
    echo date ("h:i:a");
    echo "<hr>";
    echo date ("D/d");

    echo " - " . date_default_timezone_get(); //Horario que está no servidor
   
    echo "<hr>";
    date_default_timezone_set('Europe/Amsterdam'); //Setar o fuso horario para depois imprimir
    echo date ("H:i:s");
    echo " - " . date_default_timezone_get() . "<hr>"; //Acão para imprimir o fuso horario setado

    date_default_timezone_set('America/Sao_Paulo');
    echo date ("D/d");
    echo " - " . date_default_timezone_get() . "<hr>";

    
    
    /* Função date
    D - dia da semana
    d - dia do mês
    m - mes em numeors
    M - por extenso
    y - ano com 2 digitos
    Y - ano com 4 digitos

    h - 12 horas
    H - 24 horas
    i - minutos
    s - segundos
    a - am/pm
    */


?>