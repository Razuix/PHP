<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <title>Olá, mundo!</title>
  </head>
  <body>
    <div class ="container bg-secondary pag "> 
        <h1>calculos</h1>
        <hr>
    <form name="form" method ="post" action="#">
  <div class="form-group">
    <label for="n1">Numero 1</label>
    <input type="number" class="form-control" aria-describedby="emailHelp" id="n1" name="n1" required>
  </div>
        <div class="form-group">
           <label for="operador">Operador</label>
            <select class="form-control" id="operador" name="operador" >
            <option>+</option>
            <option>-</option>
            <option>*</option>
            <option>/</option>
            </select>
        </div>


  <div class="form-group">
    <label for="n2">Numero 2</label>
    <input type="number" class="form-control" id="n2" name="n2" required>
  </div>
  
  <button type="submit" class="btn btn-primary">Calcular</button>
</form>

    <?php
        if(isset($_POST['n1'])){
          
            //Entrada 
            $n1 = $_POST['n1'];
            $n2 = $_POST['n2'];
            $operador = $_POST['operador'];

            //Processamento
            switch ($operador){
                case"+": $result = $n1 + $n2; break;
                case"-": $result = $n1 - $n2; break;
                case"*": $result = $n1 * $n2; break;
                case"/": 
        
                if($n2 == 0 ){
                 $result = "Não é possivel dividir um número por zero";
                  }
                  else{
                      $result = $n1 / $n2;
                  }
                  break;
                  default: $result = "Operador inexistente";
            }
            //Saida
             echo "<hr><h2> $n1 $operador $n2 = $result </h2>";


        }
       
    


    ?>


    <!-- JavaScript (Opcional) -->
    <!-- jQuery primeiro, depois Popper.js, depois Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>