<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
  <body>
    <div class="container bg-info pag">
        <h2>Calculo de Imposto de Renda</h2>
        <hr>
        <h4>Salário até R$1710,78 - Sem Desconto</h4>
        <h4>Salários entre R$1710,79 e R$2563,91 - 7,5% de desconto - R$128,31 (Parcela a deduzir)</h4>
        <h4>Salários entre R$2563,79 e R$3418,59 - 15% de desconto - R$128,31 (Parcela a deduzir)</h4>
        <h4>Salários entre R$3418,60 e R$4271,59 - 22,5% de desconto - R$577,31 (Parcela a deduzir)</h4>
        <h4>Salários acima R$4271,60 - 27,5% de desconto - R$790,58 (Parcela a deduzir)</h4>
        
        <hr> 
    <form name="form" method="post" action="#">
     <div class="mb-3">
        <label for="salario" class="form-label">Salario</label>
        <input type="text" class="form-control" name="salario" id="salario">
        <button type="submit" class="btn btn-primary">Calcular desconto</button>

        <?php
        if(isset($_POST['salario'])){
          
            //Entrada 
            $salario = $_POST['salario'];

            //Processamento
            if($salario < 1710){
                $perc = 0;
            }
            elseif($salario < 2563.91 ){
                $perc = 7.5;
            }
            elseif($salario < 3418.59  ){
                $perc = 15;
            }
            elseif($salario < 4271.59  ){
                $perc = 22.5;
            }
            else{
                $perc = 27.5;
            }
           
            $desconto = $salario * $perc/100;
            $pagar = $salario - $desconto;

             //Saida
             echo "<hr><h2> Valor do Salário : R$ ". number_format($valor,2,",",".") . "</h2>";
             echo "<h2> Desconto: $perc% - R$ ". number_format($desconto,2,",",".") . "</h2>";
             echo "<hr><h2> Valor a Deduzir : R$ ". number_format($pagar ,2,",",".") . "</h2>";
        }
    
    ?>

    </div>
    </form>
</div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>