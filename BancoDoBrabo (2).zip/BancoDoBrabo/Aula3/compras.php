<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
  <body>
    <div class="container bg-info pag">
        <h2>Compras</h2>
        <hr>
        <h4>Compras até R$50,00 - Sem Desconto</h4>
        <h4>Compras entre R$50,00 e R$100,00 - 5% de desconto</h4>
        <h4>Compras acima de R$100,00 - 10% de desconto</h4>
        <hr> 
    <form name="form" method="post" action="#">
     <div class="mb-3">
        <label for="valor" class="form-label">Valor</label>
        <input type="text" class="form-control" name="valor" id="valor">
        <button type="submit" class="btn btn-primary">Calcular desconto</button>

        <?php
        if(isset($_POST['valor'])){
          
            //Entrada 
            $valor = $_POST['valor'];

            //Processamento
            if($valor < 50){
                $perc = 0;
            }
            elseif($valor > 100){
                $perc = 10;
            }
            else{
                $perc = 5;
            }
           
            $desconto = $valor * $perc/100;
            $pagar = $valor - $desconto;

             //Saida
             echo "<hr><h2> Valor da compra : R$ ". number_format($valor,2,",",".") . "</h2>";
             echo "<h2> Desconto: $perc% - R$ ". number_format($desconto,2,",",".") . "</h2>";
             echo "<hr><h2> Valor a pagar: R$ ". number_format($pagar ,2,",",".") . "</h2>";
        }
    
    ?>

    </div>
    </form>
</div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>