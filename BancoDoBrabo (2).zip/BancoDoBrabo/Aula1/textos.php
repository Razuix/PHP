<?php

    echo"
       <h2 style ='text-align: center'> Funções para Strings (textos)</h2>    
        <hr>
    ";

    $nome = "Matheus Alves De Oliveira Silva";

    echo"<b> Normal: </b>";
    echo $nome;
    echo"<br>";

    echo"<b> Maiúsculo: </b>";
    echo strtoupper($nome);
    echo"<br>";
   
    echo"<b> Minúsculo: </b>";
    echo strtolower($nome);
    echo"<br>";
    
    echo"<b> Invertido: </b>";
    echo strrev($nome);
    echo"<br>";
   
    echo"<b> Quantidade de Digitos: </b>";
    echo strlen($nome);
    echo"<br>";
  
    echo"<b> Troca de Caracteres: </b>";
    echo strtr($nome,"o","_");
    echo"<br>";
  
    //substr(variavel,posição inicial,quantidade de dígitos)
    echo"<b> Partes do Texto: </b>";
    echo substr($nome,26,5);
    echo"<br>";

    echo "<b> Separando Textos: <b/>";
    $partes = explode(" ",$nome);
    $tot = count($partes)-1;
    echo "$partes[0] $partes [$tot]";
    echo"<br>";

    echo"<b> Remove espaços a esquerda: </b>";
    echo ltrim($nome);
    echo "</br>";

    echo"<b> Remove espaços a direita: </b>";
    echo rtrim($nome);
    echo "</br>";

    echo"<b> Remove espaços a direita e direita: </b>";
    echo trim($nome);
    echo "</br>";







?>