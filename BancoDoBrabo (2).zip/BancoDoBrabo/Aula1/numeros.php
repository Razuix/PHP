<?php
    echo"sorteio==>";
    echo rand(0,100);
    echo"<hr>";

    //Gerar valores aleatorios

    $a = rand(0,100);
    $b = rand(0,100);
    $c = rand(0,100);
    $d = rand(0,100);

    echo"$a - $b - $c - $d";
    echo"<hr>";

    echo"Maior ==>";
    echo max($a,$b,$c,$d);
    echo"<hr>";
   
    echo"Menor ==>>";
    echo min($a,$b,$c,$d);
    echo"<hr>";

    $e = rand(1000,50000);
    echo "R$ $e";
    echo "<hr>";
    echo "R$";
    echo number_format($e,2,",",".");
    /*number_format(variavel,n° de casas descimais, separador de casas 
    decimais, separador de milhares*/

    $f = rand(1000,2000);
    echo "R$ $f";
    echo "<hr>";
    echo "R$";
    echo number_format($f,2,",",".");


?>